#include <gtk/gtk.h>



void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_clicked                     ( GtkWidget *objet, gpointer   user_data);

void
on_button5_supp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_actt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_meilleur_clicked            (GtkButton       *button,
                                        gpointer         user_data);
