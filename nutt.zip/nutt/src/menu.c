#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include <string.h>
#include <gtk/gtk.h>
int verif(char *ID)
{
Plats P;
FILE *f;
f=fopen("plats.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %d %d %d %s",P.id,P.type,P.Nom,P.calorie,&P.date.jour,&P.date.mois,&P.date.annee,P.option)!=EOF)
{
if (strcmp(P.id,ID)==0)
{
return (1);
}
fclose(f);
return 0;
}

}
}
void ajouter (Plats P)
{
FILE *f;
f=fopen("plats.txt","a");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d %s\n",P.id,P.type,P.Nom,P.calorie,P.date.jour,P.date.mois,P.date.annee,P.option);

fclose(f);
}
}
int modifier( Plats P)
{
FILE *f1;
FILE *f2;
Plats p;
f1=fopen("plats.txt","r");
f2=fopen("plats1.txt","a+");
if ((f1!=NULL) && (f2!=NULL))
{
while(fscanf(f1,"%s %s %s %s %d %d %d %s\n ",p.id,p.type,p.Nom,p.calorie,&p.date.jour,&p.date.mois,&p.date.annee,p.option)!=EOF)
{
if (strcmp(P.id,p.id)!=0)
{
fprintf(f2,"%s %s %s %s %d %d %d %s\n ",p.id,p.type,p.Nom,p.calorie,p.date.jour,p.date.mois,p.date.annee,p.option);
}
else
{
fprintf(f2,"%s %s %s %s %d %d %d %s\n ",P.id,P.type,P.Nom,P.calorie,P.date.jour,P.date.mois,P.date.annee,P.option);
}
}
fclose(f1);
fclose(f2);
remove("plats.txt");
rename("plats1.txt","plats.txt");
return 1;
}
}

int supprimer( char num[30])
{
Plats P;

FILE *f1;
FILE *f2;

f1=fopen("plats.txt","r");
f2=fopen("plats1.txt","w");
if ((f1!=NULL) && (f2!=NULL))
{
while(fscanf(f1,"%s %s %s %s %d %d %d %s\n ",P.id,P.type,P.Nom,P.calorie,&P.date.jour,&P.date.mois,&P.date.annee,P.option)!=EOF)
{
if (strcmp(P.id, num)!=0)
{
fprintf(f2,"%s %s %s %s %d %d %d %s\n ",P.id,P.type,P.Nom,P.calorie,P.date.jour,P.date.mois,P.date.annee,P.option);
}
}
fclose(f1);
fclose(f2);
remove("plats.txt");
rename("plats1.txt","plats.txt");
return 1;
}
}

enum
{
ID, 
NOM,
TYPE,
CALORIE,
JOUR,
MOIS,
ANNEE,
OPTION,
COLUMNS
};
void afficher(GtkWidget *list)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
char id[100];
char nom[100];
char type[100];
char calorie[100];
int jour;
int mois;
int annee;
char option[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(list);
if(store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer, "text",TYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("calorie",renderer, "text",CALORIE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("option",renderer,"text",OPTION, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);

f=fopen("plats.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("plats.txt","a+");
	while(fscanf(f,"%s %s %s %s %d %d %d %s",id,nom,type,calorie, &jour, &mois, &annee,option)!=EOF)
	{
         
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, ID, id, NOM, nom, TYPE, type, CALORIE, calorie,  JOUR, jour, MOIS, mois, ANNEE, annee, OPTION, option,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
 void chercher(GtkWidget *liste,char num[30])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char id[100];
char nom[100];
char type[100];
char calorie[100];
int jour;
int mois;
int annee;
char option[100];
FILE *f;
store=NULL;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer, "text",TYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("calorie",renderer, "text",CALORIE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("option",renderer,"text",OPTION, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
}





store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);


f=fopen("plats.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("plats.txt","a+");
	while(fscanf(f,"%s %s %s %s %d %d %d %s",id,nom,type,calorie, &jour, &mois, &annee,option)!=EOF)
	{
          if(strcmp(id, num)==0)
        {
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, ID, id, NOM, nom, TYPE, type, CALORIE, calorie,  JOUR, jour, MOIS, mois, ANNEE, annee, OPTION, option,-1);
        }		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

     }
  }

void vider(GtkWidget *list)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
char id[100];
char nom[100];
char type[100];
char calorie[100];
int jour;
int mois;
int annee;
char option[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(list);
if(store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer, "text",TYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("calorie",renderer, "text",CALORIE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("option", renderer,"text",OPTION, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(list),column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
gtk_list_store_append(store,&iter);
 gtk_tree_view_set_model (GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));
	g_object_unref(store);
						  			 		

}



