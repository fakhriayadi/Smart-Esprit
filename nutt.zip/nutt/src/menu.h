#include <gtk/gtk.h>
typedef struct 
{
  int jour;
  int mois;
  int annee;
} Date;

typedef struct
{
char id[100];
char type[100];
char Nom[100];
char calorie[100];
Date date;
char option[100];
float dechet;

} Plats;


void ajouter( Plats P);
int verif(char *ID);
int supprimer(char ID[30]);
void vider(GtkWidget *list);
int modifier( Plats P);
void chercher( GtkWidget *liste,char ID[30]);
void afficher(GtkWidget *list);

