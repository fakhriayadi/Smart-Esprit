#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>
#include "menu.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
int x;
int t[7]={0,0,0,0,0,0,0};

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
  char texte1[100]="";
  char texte2[100]="";
  int test=0;
  char text[150]="";
  
  
Plats p;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *nutritionniste;
GtkWidget *outputMsg;


nutritionniste=lookup_widget(objet,"nutritionniste");
input1=lookup_widget(objet,"entry1");
input2=lookup_widget(objet,"entry2");
input3=lookup_widget(objet,"combobox1");
input4=lookup_widget(objet, "entry3");
input5=lookup_widget(objet, "spinbutton2");
input6=lookup_widget(objet, "spinbutton3");
input7=lookup_widget(objet, "spinbutton4");
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.Nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(p.calorie,gtk_entry_get_text(GTK_ENTRY(input4)));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
if (x==1)
strcpy (texte1,"  avec regime");
else
if (x==2)
strcpy (texte1,"  sans regime");
if (t[0]==1)
strcat (texte2,"  diabete");
if (t[1]==1)
strcat (texte2,"  sans sel");
if (t[2]==1)
strcat (texte2,"  proteine");
if (t[3]==1)
strcat (texte2,"  vegetarien");
if (t[4]==1)
strcat (texte2,"  boisson gazeuze");
if (t[5]==1)
strcat (texte2,"  glace");
if (t[6]==1)
strcat (texte2,"  gateau");

strcat (texte1,texte2);
strcpy(p.option,texte1);

test=verif(p.id);

switch(test)
    
{
    case 0:  
    { ajouter(p); 
     strcpy (text,"Ajout Réussi");
     outputMsg=lookup_widget(objet,("label16"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;
    case 1:
    { strcpy (text,"Identifiant déja existe");
    outputMsg=lookup_widget(objet,("label16"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
}

}


void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[6]=1;
}
}


void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[5]=1;
}
}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[4]=1;
}
}

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=2;
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[3]=1;
}

}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[2]=1;
}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[1]=1;
}
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active((togglebutton)))
{
t[0]=1 ;
}
}
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=1;
}



void
on_button2_clicked                     ( GtkWidget *objet, gpointer   user_data)
{
    GtkWidget *nutritionniste;
   	GtkWidget *idRech;
   	GtkWidget *treeview2;
      	GtkWidget *outputMsg;
   	int test;
    	char text[100];
   	char ID[20];
   
nutritionniste=lookup_widget(objet,"nutritionniste");
treeview2=lookup_widget(nutritionniste,"treeview1");

idRech=lookup_widget(objet,"entry4");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(idRech)));

test=verif(ID);

switch(test)
    
{
    case 0:  
    { strcpy (text,"Plat n'existe pas");
    outputMsg=lookup_widget(objet,("label18"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  chercher(treeview2, ID);
       strcpy (text,"Plat trouvé");
       outputMsg=lookup_widget(objet,("label18"));
       gtk_label_set_text(GTK_LABEL(outputMsg),text);
      }
    break; 
    
} 

}


void
on_button5_supp_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{
        GtkWidget *input1;
     	GtkWidget *nutritionniste;
     	GtkWidget *outputMsg;
	Plats P;
	
        int test,supp;
        char text[100];
        char id [20];
     




nutritionniste=lookup_widget(objet,"nutritionniste");
input1=lookup_widget(objet,"entry5");   
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));

//supp=supprimer(ID);

test=verif(id);


switch(test)
    
{
    case 0:
   
     
    { strcpy (text,"le plat  n'existe pas");
    outputMsg=lookup_widget(objet,("label15"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
  
    break;
    case 1:
     
     {
     supp=supprimer(id);
     strcpy (text,"Suppression Réussi");
     outputMsg=lookup_widget(objet,("label15"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;

}
}



void
on_button3_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *nutritionniste;
GtkWidget *treeview1;

nutritionniste=lookup_widget(objet,"nutritionniste");
treeview1=lookup_widget(nutritionniste,"treeview1");

afficher(treeview1);

}


void
on_button4_actt_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{

  GtkWidget *nutritionniste;
GtkWidget *treeview1;

nutritionniste=lookup_widget(objet,"nutritionniste");
treeview1=lookup_widget(nutritionniste,"treeview1");


vider(treeview1);
afficher(treeview1);

}


void
on_button6_ret_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
char texte1[100]="";
  char texte2[100]="";
  int test,modif;
  char text[150]="";
  
  
Plats p;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*modifID;
GtkWidget *nutritionniste;
GtkWidget *outputMsg;

if (x==1)
strcpy (texte1,"  avec regime");
else
if (x==2)
strcpy (texte1,"  sans regime");
if (t[0]==1)
strcat (texte2,"  diabete");
if (t[1]==1)
strcat (texte2,"  sans sel");
if (t[2]==1)
strcat (texte2,"  proteine");
if (t[3]==1)
strcat (texte2,"  vegetarien");
if (t[4]==1)
strcat (texte2,"  boisson gazeuze");
if (t[5]==1)
strcat (texte2,"  glace");
if (t[6]==1)
strcat (texte2,"  gateau");

strcat (texte1,texte2);
strcpy(p.option,texte1);
nutritionniste=lookup_widget(objet,"nutritionniste");
input1=lookup_widget(objet,"entry1");
input2=lookup_widget(objet,"entry2");
input3=lookup_widget(objet,"combobox1");
input4=lookup_widget(objet, "entry3");
input5=lookup_widget(objet, "spinbutton2");
input6=lookup_widget(objet, "spinbutton3");
input7=lookup_widget(objet, "spinbutton4");
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.Nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(p.calorie,gtk_entry_get_text(GTK_ENTRY(input4)));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));

test=verif(p.id);

switch(test)
    
{
    case 0:
    { strcpy(text,"Plat n'existe pas");
    outputMsg=lookup_widget(objet,("label19"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;

    case 1:
     
     {
     modif=modifier(p);
     strcpy (text,"Modification Réussi");
     outputMsg=lookup_widget(objet,("label19"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;

}
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button2_meilleur_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}

