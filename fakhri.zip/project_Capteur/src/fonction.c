#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "fonction.h"
#include <gtk/gtk.h>
enum{
NOM,
TYPE,
ID,
DC,
DMS,
DP,
ETAT,
COLUMNS
};
//ajouter capteur//
void FFajouter(cap C)
{
    FILE* f = NULL;
    f=fopen("capteurs.txt","a+");
    if (f!=NULL)
    {
    
    fprintf(f,"%s %s %s %d/%d/%d %d/%d/%d %d/%d/%d %s\n",C.t.nom,C.t.type,C.t.id,C.dc.jour,C.dc.mois,C.dc.annee,C.dms.jour,C.dms.mois,C.dms.annee,C.dp.jour,C.dp.mois,C.dp.annee,C.etat);
      
    fclose(f);
}
    
    else printf("impossible d'ouvrir le fichier\n");
    
}


// Supprimer un capteur par son identifiant//
int FFsupprimer(cap C,char id1[30])
{
FILE *f = NULL;
FILE *f1 = NULL;

f=fopen("capteurs.txt","r");
f1=fopen("temperature.txt","w");
if (f!=NULL)
{

while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %d %d %s\n",C.t.nom,C.t.type,C.t.id,&C.dc.jour,&C.dc.mois,&C.dc.annee,&C.dms.jour,&C.dms.mois,&C.dms.annee,&C.dp.jour,&C.dp.mois,&C.dp.annee,C.etat)!=EOF)
{

if (strcmp(C.t.id,id1)!=0){
fprintf(f1,"%s %s %s %d/%d/%d %d/%d/%d %d/%d/%d %s\n",C.t.nom,C.t.type,C.t.id,C.dc.jour,C.dc.mois,C.dc.annee,C.dms.jour,C.dms.mois,C.dms.annee,C.dp.jour,C.dp.mois,C.dp.annee,C.etat);
}
}
}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("temperature.txt" , "capteurs.txt");
return 1 ;
}


//modifier un capteur //
int FFmodifier(cap C)
{
cap newcap;	
FILE*f;
FILE*f1;
f=fopen("capteurs.txt","r");
f1=fopen("temperature.txt","w");

if ((f!=NULL) && (f1!=NULL))
    {
while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %d %d %s\n",C.t.nom,C.t.type,C.t.id,&C.dc.jour,&C.dc.mois,&C.dc.annee,&C.dms.jour,&C.dms.mois,&C.dms.annee,&C.dp.jour,&C.dp.mois,&C.dp.annee,C.etat)!=EOF)
    {
if(strcmp(C.t.id,newcap.t.id)==0)
    {
fprintf(f1,"%s %s %s %d %d %d %d %d %d %d %d %d %s\n",C.t.nom,C.t.type,C.t.id,C.dc.jour,C.dc.mois,C.dc.annee,C.dms.jour,C.dms.mois,C.dms.annee,C.dp.jour,C.dp.mois,C.dp.annee,C.etat);
    }
else
    {

fprintf(f1,"%s %s %s %d %d %d %d %d %d %d %d %d %s\n",newcap.t.nom,newcap.t.type,newcap.t.id,newcap.dc.jour,newcap.dc.mois,newcap.dc.annee,newcap.dms.jour,newcap.dms.mois,newcap.dms.annee,newcap.dp.jour,newcap.dp.mois,newcap.dp.annee,newcap.etat);
    }
    }
fclose(f);
fclose(f1);

remove("capteurs.txt");
rename("temperature.txt","capteurs.txt");
return 1;
}        
}  

//chercher capteur par son identifiant//
int FFchercher(GtkWidget *liste,char id1[30])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char nom [30];
char type [30] ;
char id[30] ;
char dc [30];
char dms [30];
char dp [30];
char etat [30];
cap C;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom", renderer, "text",NOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("type", renderer, "text",TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id", renderer, "text",ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("dc", renderer, "text",DC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("dms", renderer, "text",DMS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("dp", renderer, "text",DP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("etat", renderer,"text",ETAT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
	
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("capteurs.txt","r");
if(f==NULL)
{
return;
}

else
{
f = fopen("capteurs.txt","a+");

while(fscanf(f,"%s %s %s %s %d %d %d %d",nom,type,id,dc,dms,dp,etat)!=EOF)
{
if(strcmp(id,id1)==0)                						  
{
gtk_list_store_append(store, &iter);						  			 	
gtk_list_store_set (store, &iter, NOM, nom, TYPE, type, ID, id, DC, dc, DMS, dms, DP, dp, ETAT, etat,-1);		
}
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}




// vérifier un capteur par son identifiant//
int FFverifier(char *id)
{
cap C;
FILE *f = NULL;
f=fopen("capteurs.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %d %d %s\n",C.t.nom,C.t.type,C.t.id,&C.dc.jour,&C.dc.mois,&C.dc.annee,&C.dms.jour,&C.dms.mois,&C.dms.annee,&C.dp.jour,&C.dp.mois,&C.dp.annee,C.etat)!=EOF)
{
if (strcmp(C.t.id,id)!=0)
return 1;
}
fclose(f);
return 0;
}
}



enum
{	
	ETAGE,
	JOUR,
        HEURE,
        TEMPERATURE,
	COLUMNS1 
};
//afficher les capteurs défectueux //
void capteur_defectueux(GtkWidget *liste)

{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
int etage;
int jour;
int heure;
float temperature;
defectueux def;
store=NULL;

FILE *f2;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("etage", renderer, "text",ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("heure", renderer, "text",HEURE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("temperature", renderer, "text",TEMPERATURE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);

}
	
store=gtk_list_store_new(COLUMNS1,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_FLOAT);
f2 = fopen("Dashboard.txt","r");
if(f2 == NULL)
{
return;
}

else
{
f2 = fopen("Dashboard.txt","a+");

while(fscanf(f2,"%d %d %d %f\n",&etage,&jour,&heure,&temperature)!=EOF)
{
if ((temperature<10) || (temperature>30))                						  
{
gtk_list_store_append(store, &iter);						  			 	
gtk_list_store_set (store,&iter,ETAGE,etage,JOUR,jour,HEURE,heure,TEMPERATURE,temperature,-1);		
}
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}



//afficher tous les capteurs //
void FFafficher (GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;


char nom[30];
char type[30];
char id[30]; 
char dc[30];
char dms[30];
char dp[30];
char etat[100];     


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dc",renderer,"text",DC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dms",renderer,"text",DMS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("dp",renderer,"text",DP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer,"text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("capteurs.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("capteurs.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,type,id,dc,dms,dp,etat)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,TYPE,type,ID,id,DC,dc,DMS,dms,DP,dp,ETAT,etat,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}


