#include <gtk/gtk.h>


void
on_button_Ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_Modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_Supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_Chercher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_ajouter_Non_defectueux_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_Defectueux_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_Afficher1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_Actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_treeview_Temperature_Defectueux_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_button_AfficherTemperature_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);
