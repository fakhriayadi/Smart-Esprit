#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
#include <gtk/gtk.h>
typedef struct {
int jour;
int mois;
int annee;
}date;

typedef struct {
char nom[30];
char type[30];
char id[30]; 
}typecapteur;

typedef struct capteur {
typecapteur t;                           
date dc;
date dms;
date dp;
char etat[100];     
}cap;

typedef struct {
int etage;
int jour;
int heure;
float temperature;


}defectueux; 

void FFajouter(cap C);
int FFmodifier(cap C);
int FFsupprimer(cap C,char id1[30]);
int FFchercher(GtkWidget *liste,char id1[30]);
int FFverifier(char *id);
void capteur_defectueux(GtkWidget *liste);
void FFafficher(GtkWidget *liste);






#endif // FUNCTION_H_INCLUDED
