#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "stdlib.h"
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include "fonction.h"
int x,CB;

void
on_button_Ajouter_clicked              (GtkWidget      *objet,
                                        gpointer         user_data)
{
char e[100];
cap C;
GtkWidget *input1, *input2, *input3, *input4, *input5 ,*input6,*input7, *input8, *input9 ,*input10 ,*input11 ,*input12 ;

input1=lookup_widget(objet,"ajouter_Nom");
input2=lookup_widget(objet,"ajouter_Id");
input3=lookup_widget(objet,"ajouter_Dcj");
input4=lookup_widget(objet,"ajouter_Dcm");
input5=lookup_widget(objet,"ajouter_Dca");
input6=lookup_widget(objet,"ajouter_Dmsj");
input7=lookup_widget(objet,"ajouter_Dmsm");
input8=lookup_widget(objet,"ajouter_Dmsa");
input9=lookup_widget(objet,"ajouter_Dpj");
input10=lookup_widget(objet,"ajouter_Dpm");
input11=lookup_widget(objet,"ajouter_Dpa");
input12=lookup_widget(objet,"ajouter_Type");

strcpy(C.t.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(C.t.id,gtk_entry_get_text(GTK_ENTRY(input2)));

C.dc.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
C.dc.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
C.dc.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
C.dms.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
C.dms.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
C.dms.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
C.dp.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
C.dp.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10));
C.dp.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input11));

strcpy(C.t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input12)));
if (x == 1)
strcpy(e,"Etatnondéfectueux");
else
strcpy(e,"Etatdéfectueux");
strcpy(C.etat,e);

FFajouter(C);
}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


GtkTreeIter iter;
gchar *nom;
gchar *type;
gchar *id;
gchar *dc;
gchar *dms;
gchar *dp;
gchar *etat;

typecapteur t;
cap C;
char id1[30];

GtkTreeModel *model=gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nom,1,&type,2,&id,3,&dc,4,&dms,5,&dp,6,&etat,-1);
strcpy(C.t.nom,nom);
strcpy(C.t.type,type);
strcpy(C.t.id,id);
strcpy(C.etat,etat);
FFsupprimer(C,id1);
FFafficher(treeview);
}
}



void
on_button_Modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
cap C;
char id1[30];
int t,m;
char message[30];
GtkWidget *input1, *input2, *input3, *input4, *input5 ,*input6,*input7, *input8, *input9 ,*input10 ,*input11 ,*input12 ,*message5;

input1=lookup_widget(objet,"ajouter_Nom");
input2=lookup_widget(objet,"ajouter_Id");
input3=lookup_widget(objet,"ajouter_Dcj");
input4=lookup_widget(objet,"ajouter_Dcm");
input5=lookup_widget(objet,"ajouter_Dca");
input6=lookup_widget(objet,"ajouter_Dmsj");
input7=lookup_widget(objet,"ajouter_Dmsm");
input8=lookup_widget(objet,"ajouter_Dmsa");
input9=lookup_widget(objet,"ajouter_Dpj");
input10=lookup_widget(objet,"ajouter_Dpm");
input11=lookup_widget(objet,"ajouter_Dpa");
input12=lookup_widget(objet,"ajouter_Type");


message5=lookup_widget(objet,"label_Message1");

strcpy(C.t.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(C.t.id,gtk_entry_get_text(GTK_ENTRY(input2)));

C.dc.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
C.dc.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
C.dc.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
C.dms.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
C.dms.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
C.dms.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
C.dp.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
C.dp.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10));
C.dp.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input11));


strcpy(C.t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input12)));




gtk_label_set_text(GTK_LABEL(message5),"Modification avec succés"); 

}




void
on_button_Supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
cap C;
char id1[20],id2[20];
char s1[20] , s2[20],s3[20] ,s4[20],s5[20],s6[20],s7[20];
char msg [50];
int test=0;
FILE *f,*g ;
input1= lookup_widget (objet, "modifier_Id");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("capteurs.txt","r");
g=fopen("temperature.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s %s ", &s1,&s2,&id2,&s3,&s4,&s5,&s6,&s7) == 7)
    if (strcmp (id2, id1) != 0)
      fprintf (g, "%s %s %s %s %s %s %s\n", s1,s2,id2,s3,s4,s5,s6,s7);
  fclose(f);
  fclose(g);
f=fopen("capteurs.txt","w");
g=fopen("temperature.txt","r");
  while (fscanf (g, "%s %s %s %s %s %s %s ", &s1,&s2,&id2,&s3,&s4,&s5,&s6,&s7) == 7)
      fprintf (f,"%s %s %s %s %s %s %s\n", s1,s2,id2,s3,s4,s5,s6,s7);
 fclose (f);
 fclose(g);
}





void
on_button_Chercher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *window_Capteur;
GtkWidget *rid;
GtkWidget *treeview5;
GtkWidget *treeview1;
GtkWidget *outputMsg;
int v;
char text[200];
char id1[20];
   
window_Capteur=lookup_widget(objet,"window_Capteur");
treeview5=lookup_widget(window_Capteur,"treeview1");

rid=lookup_widget(objet,"chercher_id");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(rid)));

v=FFverifier(id1);

switch(v)
    
{
    case 0:  
    { strcpy (text,"Capteur introuvable!");
      outputMsg=lookup_widget(objet,("label_Message2"));
      gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  FFchercher(treeview5, id1);
       strcpy (text,"Capteur trouvable");
       outputMsg=lookup_widget(objet,("label_Message2"));
       gtk_label_set_text(GTK_LABEL(outputMsg),text);
      }
    break; 
    break;
} 

}


void
on_ajouter_Non_defectueux_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ x=1;

}
}



void
on_ajouter_Defectueux_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{ x=2;
}
}



void
on_button_Afficher1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *window_Capteur;
GtkWidget *treeview1;

window_Capteur=lookup_widget(objet,"window_Capteur");

treeview1=lookup_widget(window_Capteur,"treeview1");

FFafficher(treeview1);
}



void
on_button_Actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_Capteur,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"window_Capteur");
window_Capteur=create_window_Capteur();

gtk_widget_show(window_Capteur);

gtk_widget_hide(w1);

treeview1=lookup_widget(window_Capteur,"treeview1");
FFafficher(treeview1);
}



void
on_treeview_Temperature_Defectueux_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}





void
on_button_AfficherTemperature_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_Capteur;
GtkWidget *treeviewTD;

window_Capteur=lookup_widget(objet,"window_Capteur");
treeviewTD=lookup_widget(window_Capteur,"treeview_Temperature_Defectueux");

capteur_defectueux (treeviewTD);
}

