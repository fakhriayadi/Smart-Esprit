#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "admin.h"
#include <string.h>
int x,y;

void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowAjouter;
GtkWidget *gestion;
gestion=lookup_widget(button,"principal");
gtk_widget_destroy(gestion);
windowAjouter=create_ajouter();
gtk_widget_show (windowAjouter);
}


void
on_modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowModifier;
GtkWidget *gestion;
gestion=lookup_widget(button,"principal");
gtk_widget_destroy(gestion);
windowModifier=create_formulaire();
gtk_widget_show (windowModifier);
}


void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowSupprimer;
GtkWidget *gestion;
gestion=lookup_widget(button,"principal");
gtk_widget_destroy(gestion);
windowSupprimer=create_supprimer();
gtk_widget_show (windowSupprimer);
}


void
on_rechercher_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowChercher;
GtkWidget *gestion;
gestion=lookup_widget(button,"principal");
gtk_widget_destroy(gestion);
windowChercher=create_rechercher();
gtk_widget_show (windowChercher);
}


void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion;
GtkWidget *Afficher;
GtkWidget *treeview3;

//gestion=lookup_widget(button,"principal");
//gtk_widget_destroy(gestion);
Afficher=lookup_widget(button,"afficher");
//Afficher=create_afficher();
//gtk_widget_show(Afficher);
treeview3=lookup_widget(Afficher,"treeview3");
afficher(treeview3);
}


void
on_valider1_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
Admin A;

GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8;
GtkWidget *Ajouter;

Ajouter=lookup_widget(button,"ajouter");

input1=lookup_widget(button,"entry_nom1");
input2=lookup_widget(button,"entry_prenom1");
input3=lookup_widget(button,"Jour1");
input4=lookup_widget(button,"Mois1");
input5=lookup_widget(button,"Annee1");
input6=lookup_widget(button,"entry_user1");
input7=lookup_widget(button,"entry_id1");
input8=lookup_widget(button,"entry_password1");


strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
A.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
A.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
A.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
strcpy(A.username,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(A.id,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(A.password,gtk_entry_get_text(GTK_ENTRY(input8)));
if (x==1)
strcpy(A.role,"technicien");
if (x==2)
strcpy(A.role,"nutritionniste");
if (x==3)
strcpy(A.role,"agent_de_foyer");
if (x==4)
strcpy(A.role,"agent_du_restaurant");
if (x==5)
strcpy(A.role,"etudiant");
if (x==6)
strcpy(A.role,"organisateur evenementiel");

ajouter(A);
}


void
on_annuler1_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajouter;
GtkWidget *gestion;
Ajouter=lookup_widget(button,"ajouter");
gtk_widget_destroy(Ajouter);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_valider6_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
Admin a;

GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8 , *output;
GtkWidget *formulaire;
int test;
char num[30];
char commentaire[30];

formulaire=lookup_widget(button,"formulaire");
output=lookup_widget(button,"commentaire3");

input1=lookup_widget(button,"entry_nom2");
input2=lookup_widget(button,"entry_prenom2");
input3=lookup_widget(button,"Jour2");
input4=lookup_widget(button,"Mois2");
input5=lookup_widget(button,"Annee2");
input6=lookup_widget(button,"entry_user2");
input7=lookup_widget(button,"entry_password2");
input8=lookup_widget(button,"entry_id");
//input9=lookup_widget(button,"entry_id2");



strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
strcpy(a.username,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(num,gtk_entry_get_text(GTK_ENTRY(input8)));
//strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(a.password,gtk_entry_get_text(GTK_ENTRY(input7)));
if (y==1)
strcpy(a.role,"technicien");
if (y==2)
strcpy(a.role,"nutritionniste");
if (y==3)
strcpy(a.role,"agent_de_foyer");
if (y==4)
strcpy(a.role,"agent_du_restaurant");
if (y==5)
strcpy(a.role,"etudiant");
if (y==6)
strcpy(a.role,"organisateur evenementiel");
test=verif(num);
if(test==1)
{
modifier(a,num);
}
else
{
strcpy(commentaire,"Cet id n'existe pas");
gtk_label_set_text(GTK_LABEL(output),commentaire);
return;
}
}


void
on_annuler6_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *formulaire;
GtkWidget *gestion;
formulaire=lookup_widget(button,"formulaire");
gtk_widget_destroy(formulaire);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_valider2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowdonnees;
GtkWidget *input, *output, *Modifier;
char num[30];
int test;
char commentaire[30];
Modifier=lookup_widget(button,"modifier");
input=lookup_widget(button,"entry_id3");
output=lookup_widget(button,"commentaire");
strcpy(num,gtk_entry_get_text(GTK_ENTRY(input)));

test=verif(num);
if(test==1)
{
gtk_widget_destroy(Modifier);
windowdonnees=create_formulaire();
gtk_widget_show (windowdonnees);
}
else
{
strcpy(commentaire,"Cet id n'existe pas");
gtk_label_set_text(GTK_LABEL(output),commentaire);
return;
}
}


void
on_annuler2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier;
GtkWidget *gestion;
modifier=lookup_widget(button,"modifier");
gtk_widget_destroy(modifier);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_valider3_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
Admin A;
GtkWidget *input, *output, *Supprimer;
char num[30];
int test;
char commentaire[30];

Supprimer=lookup_widget(button,"supprimer");
input=lookup_widget(button,"entry_id4");
output=lookup_widget(button,"commentaire1");
strcpy(num,gtk_entry_get_text(GTK_ENTRY(input)));
test=verif(num);
if(test==1)
{
supprimer(A, num);
}
else
{
strcpy(commentaire,"Cet id n'existe pas");
gtk_label_set_text(GTK_LABEL(output),commentaire);
return;
}
}


void
on_annuler3_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer;
GtkWidget *gestion;
supprimer=lookup_widget(button,"supprimer");
gtk_widget_destroy(supprimer);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_valider4_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input, *output;
GtkWidget *Chercher;
GtkWidget *Affichage;
GtkWidget *treeview2;
char num[30];
int test;
char commentaire[30];

Chercher=lookup_widget(button,"rechercher");
input=lookup_widget(button,"entry_id5");
output=lookup_widget(button,"commentaire2");
strcpy(num,gtk_entry_get_text(GTK_ENTRY(input)));
test=verif(num);
if(test==1)
{
gtk_widget_destroy(Chercher);
Affichage=lookup_widget(button,"affichage");
Affichage=create_affichage();
gtk_widget_show(Affichage);
treeview2=lookup_widget(Affichage,"treeview2");
chercher(treeview2,num);
}
else
{
strcpy(commentaire,"Cet id n'existe pas");
gtk_label_set_text(GTK_LABEL(output),commentaire);
return;
}
}


void
on_annuler4_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *rechercher;
GtkWidget *gestion;
rechercher=lookup_widget(button,"rechercher");
gtk_widget_destroy(rechercher);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_annuler5_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher;
GtkWidget *gestion;
afficher=lookup_widget(button,"afficher");
gtk_widget_destroy(afficher);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_annuler7_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *affichage;
GtkWidget *gestion;
affichage=lookup_widget(button,"affichage");
gtk_widget_destroy(affichage);
gestion=create_principal();
gtk_widget_show(gestion);
}


void
on_technicien1_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}

}


void
on_nutritionniste1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}

}


void
on_agent_de_foyer1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=3;}

}


void
on_agent_du_restaurant1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=4;}

}


void
on_etudiant1_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=5;}

}


void
on_technicien2_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_nutritionniste2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}


void
on_agent_de_foyer2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=3;}
}


void
on_agent_du_restaurant_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=4;}
}


void
on_etudiant2_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=5;}
}


void
on_organisateur1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=6;}
}


void
on_organisateur2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=6;}
}


void
on_nbetudiant_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output1, *output2, *output3;
int niveau1=0,niveau2=0,niveau3=0;
char commentaire1[70];
char commentaire2[70];
char commentaire3[70];
output1=lookup_widget(button,"niveau1");
output2=lookup_widget(button,"niveau2");
output3=lookup_widget(button,"niveau3");
nbetudiant(&niveau1, &niveau2, &niveau3);
sprintf(commentaire1,"%d",niveau1);
//strcpy(commentaire1,niveau1);
strcat(commentaire1," étudiants dans le niveau 1");
gtk_label_set_text(GTK_LABEL(output1),commentaire1);
sprintf(commentaire2,"%d",niveau2);
//strcpy(commentaire2,niveau2);
strcat(commentaire2," étudiants dans le niveau 2");
gtk_label_set_text(GTK_LABEL(output2),commentaire2);
sprintf(commentaire3,"%d",niveau3);
//strcpy(commentaire3,niveau3);
strcat(commentaire3," étudiants dans le niveau 3");
gtk_label_set_text(GTK_LABEL(output3),commentaire3);
}

