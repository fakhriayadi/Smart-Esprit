#include <stdio.h>
#include <stdlib.h>
#include "admin.h"
#include <string.h>
#include<gtk/gtk.h>

enum
{
NOM,
PRENOM,
JOUR,
MOIS,
ANNEE,
USERNAME,
ID,
PASSWORD,
ROLE,
COLUMNS
};

void ajouter (Admin A)
{
FILE *f;
f=fopen("admin.txt","a+");
if(f!=NULL)
{
fprintf(f," %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,A.date.jour,A.date.mois,A.date.annee,A.username,A.id,A.password,A.role);
}
fclose(f);
}

void modifier( Admin a, char num[30])
{
FILE *f1;
FILE *f2;
Admin A;
f1=fopen("admin.txt","r");
f2=fopen("admin1.txt","a+");
if ((f1!=NULL) && (f2!=NULL))
{
while(fscanf(f1,"  %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,&A.date.jour,&A.date.mois,&A.date.annee,A.username,A.id,A.password,A.role)!=EOF)
{
if (strcmp(A.id,num)!=0)
{
fprintf(f2,"  %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,A.date.jour,A.date.mois,A.date.annee,A.username,A.id,A.password,A.role);
}
else
{
fprintf(f2, "  %s %s %d %d %d %s %s %s %s \n",a.nom,a.prenom,a.date.jour,a.date.mois,a.date.annee,a.username,num,a.password,a.role);
}
}
fclose(f1);
fclose(f2);
remove("admin.txt");
rename("admin1.txt","admin.txt");
}
}

void supprimer(Admin A, char num[30])
{
FILE *f1;
FILE *f2;

f1=fopen("admin.txt","r");
f2=fopen("admin1.txt","a+");
if ((f1!=NULL) && (f2!=NULL))
{
while(fscanf(f1, "  %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,&A.date.jour,&A.date.mois,&A.date.annee,A.username,A.id,A.password,A.role )!=EOF)
{
if (strcmp(A.id, num)!=0)
{
fprintf(f2, " %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,A.date.jour,A.date.mois,A.date.annee,A.username,A.id,A.password,A.role);
}
}
fclose(f1);
fclose(f2);
remove("admin.txt");
rename("admin1.txt","admin.txt");
}
else
{return;}
}

void afficher( GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

  
Admin A;
 
  store=NULL;

FILE *f;
store= gtk_tree_view_get_model(liste);


if (store==NULL)
{


renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("UserName",renderer,"text",USERNAME,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Password",renderer,"text",PASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT , G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING, G_TYPE_STRING);
f=fopen("admin.txt","r");
if(f==NULL)
{return;}
else
{
f=fopen("admin.txt","a+");
while(fscanf(f," %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,&A.date.jour,&A.date.mois,&A.date.annee,A.username,A.id,A.password,A.role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,A.nom,PRENOM,A.prenom,JOUR,A.date.jour,MOIS,A.date.mois,ANNEE,A.date.annee,USERNAME,A.username,ID,A.id,PASSWORD,A.password,ROLE,A.role,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void chercher(GtkWidget *liste,char num[30])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
Admin A;
 
  store=NULL;

FILE *f;
store= gtk_tree_view_get_model(liste);


if (store==NULL)
{


renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("UserName",renderer,"text",USERNAME,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Password",renderer,"text",PASSWORD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer= gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT , G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING, G_TYPE_STRING);
f=fopen("admin.txt","r");
if(f==NULL)
{return;}
else
{
f=fopen("admin.txt","a+");
while(fscanf(f," %s %s %d %d %d %s %s %s %s \n",A.nom,A.prenom,&A.date.jour,&A.date.mois,&A.date.annee,A.username,A.id,A.password,A.role)!=EOF)
{
if (strcmp(A.id,num)==0)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,A.nom,PRENOM,A.prenom,JOUR,A.date.jour,MOIS,A.date.mois,ANNEE,A.date.annee,USERNAME,A.username,ID,A.id,PASSWORD,A.password,ROLE,A.role,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);

}
}
	
	
	



int verif(char num[30])
{
Admin A;
FILE *f;
f=fopen("admin.txt","r");
if (f!=NULL)
{
while(fscanf(f, " %s %s %d %d %d %s %s %s %s  \n",A.nom,A.prenom,&A.date.jour,&A.date.mois,&A.date.annee,A.username,A.id,A.password,A.role)!=EOF)
{
if (strcmp(A.id,num)==0)
{
return (1);
}
}
}
}

int nbetudiant(int *niveau1, int *niveau2, int *niveau3)
{
Etudiant E;
FILE *f;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while(fscanf(f, " %s %s %s %d \n",E.id,E.nom,E.prenom,&E.niveau)!=EOF)
{
if (E.niveau==1)
*niveau1=*niveau1+1;
else if (E.niveau==2)
*niveau2=*niveau2+1;
else if (E.niveau==3)
*niveau3=*niveau3+1;
}
}
}



