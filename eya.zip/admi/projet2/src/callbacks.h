#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler1_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider6_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler6_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider3_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler3_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider4_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler4_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler5_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_annuler7_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_technicien1_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nutritionniste1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_agent_de_foyer1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_agent_du_restaurant1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_etudiant1_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_technicien2_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nutritionniste2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_agent_de_foyer2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_agent_du_restaurant_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_etudiant2_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_organisateur1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_organisateur2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nbetudiant_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
