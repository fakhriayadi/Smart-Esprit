#include <stdio.h>
#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
} Date;
typedef struct
{
  char nom[30];
  char prenom[30];
  char username[30];
  char password[30];
  char id[30];
  char role[30];
Date date;
} Admin;
typedef struct
{
  char nom[30];
  char prenom[30];
  char id[30];
  int niveau;
} Etudiant;

int verif(char num[30]);
void ajouter( Admin A);
void supprimer( Admin A, char num[30]);
void modifier( Admin a, char num[30]);
void chercher(GtkWidget *liste,char num[30]);
void afficher( GtkWidget *liste);
int nbetudiant(int *niveau1, int *niveau2, int *niveau3);

