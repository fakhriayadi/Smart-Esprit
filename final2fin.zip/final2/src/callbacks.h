#include <gtk/gtk.h>


void
on_ajouter_jihen_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_stock_jihen_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_repture_jihen_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_jihen_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_recherche_jihen_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_jihen_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_supp_jihen_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_validerjihen_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserjihen_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkmodif_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_affichdashboard_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_facebook_jihen_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_instagram_jihen_clicked             (GtkButton       *button,
                                        gpointer         user_data);
