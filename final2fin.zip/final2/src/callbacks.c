#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "final.h"
#include<stdio.h>
#include<support.h>
#include <stdlib.h>
#include <string.h>

int x=1,y=0,t=0;
int y2=0;
void
on_checkmodif_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active( togglebutton))
y2=1;

}


void
on_stock_jihen_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	x=1;
}


void
on_repture_jihen_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	x=2;

}


void
on_check_jihen_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active( togglebutton))
y=1;


}
void
on_ajouter_jihen_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{int x1,x2,x3;
FILE *F=NULL;
stock s;
char text[100]="";
char text1[100]="";
char text2[100]="";
char text3[100]="";

char quantite1 [20];
char prix1 [20];
 
GtkWidget *input1, *input2, *input3, *input4, *combobox1 , *input5, *input6 ,*spin2, *spin3, *spin4 ,*output,*output1,*output2,*output3;
GtkWidget *quantite, *prix ;

input1=lookup_widget(button,"nomjihen");
input2=lookup_widget(button,"refjihen");
input3=lookup_widget(button,"catjihen");
input4=lookup_widget(button,"qjihen");
input5=lookup_widget(button,"fourjihen");
input6=lookup_widget(button,"prixjihen");
spin2=lookup_widget(button,"jourjihen");
spin3=lookup_widget(button,"moisjihen");
spin4=lookup_widget(button,"anneejihen");

strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.ref,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s.cat,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s.quantite,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(s.four,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(s.prix,gtk_entry_get_text(GTK_ENTRY(input6)));


s.d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spin2));
s.d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spin3));
s.d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spin4));

combobox1=lookup_widget(button,"combobox1");
strcpy(s.rang,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

if (x==1)
	strcpy(s.etat,"en-stock");
if (x==2)
	strcpy(s.etat,"en-repture-de-stock");


//ajouter(s);

t=verif(s.ref);

quantite=lookup_widget(button,"qjihen");
strcpy(quantite1,gtk_entry_get_text(GTK_ENTRY(quantite)));
x1=controle(quantite1);

prix=lookup_widget(button,"prixjihen");
strcpy(prix1,gtk_entry_get_text(GTK_ENTRY(prix)));
x2=controle(prix1);




if((y==1)&&(t==0)&&(x1==0)&&(x2==0))
{
sprintf(text,"ajout avec succes ");
output=lookup_widget(button,"label25jihen");
gtk_label_set_text(GTK_LABEL(output),text);
ajouter(s);

sprintf(text1,"");
output1=lookup_widget(button, "controle_quantite");
gtk_label_set_text(GTK_LABEL(output1),text1);

sprintf(text2,"");
output2=lookup_widget(button, "controle_prix");
gtk_label_set_text(GTK_LABEL(output2),text2);

sprintf(text3,"");
output3=lookup_widget(button, "controle_reference");
gtk_label_set_text(GTK_LABEL(output3),text3);

}

else
{
sprintf(text,"erreur");
output=lookup_widget(button,"label25jihen");
gtk_label_set_text(GTK_LABEL(output),text);
}


if(x1==1)
{
sprintf(text1,"quantite est un entier!");
output1=lookup_widget(button, "controle_quantite");
gtk_label_set_text(GTK_LABEL(output1),text1);
}

if(x2==1)
{
sprintf(text2,"prix est un entier!");
output2=lookup_widget(button, "controle_prix");
gtk_label_set_text(GTK_LABEL(output2),text2);
}


if(t==1)
{
sprintf(text3,"ce produit existe déja!");
output3=lookup_widget(button, "controle_reference");
gtk_label_set_text(GTK_LABEL(output3),text3);
}


//<b><span color="grey"> </span></b>



}





void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
stock s;;	
	GtkTreeIter iter;
	gchar*nom;
	gchar*ref;
	gchar*cat;
	gchar*prix;
	gchar*rang;
	gchar*quantite;
	gchar*four;
	gchar*etat;
	gchar*rangement;
        gchar*j;
	gchar*m;
	gchar*a;
	char jour[20];
	char mois[20];
	char annee[20];
	jour=="s.j";
	mois=="s.m";
	annee=="s.a";

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention de valeur de la ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,nom,1,ref,2,cat,3,rang,4,quantite,5,four,6,prix,7,etat,8,jour,9,mois,10,annee,-1);
	//copier de valeur dans la variable n
	strcpy(s.nom,nom);
	strcpy(s.ref,ref);
	strcpy(s.cat,cat);
	strcpy(s.rang,rangement);
	strcpy(s.quantite,quantite);
	strcpy(s.four,four);
	strcpy(s.prix,prix);
	strcpy(s.etat,etat);
	strcpy(jour,j);
	strcpy(mois,m);
	strcpy(annee,a);

	supprimer(ref);
	//appelle a la fonction afficher
	afficher(treeview);
	afficher_rech(treeview);
	}


}


void
on_recherche_jihen_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{stock s;
char text4[100]="";
int t;
GtkWidget *output;
GtkWidget *treeview1;
GtkWidget *reference1;
char ref[20];
FILE *f;
FILE *g;
reference1=lookup_widget(button,"refrechjihen");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(reference1)));
t=verif(s.ref);

/*chercher(ref);
treeview1=lookup_widget(button,"treeview1");
afficher_rech(treeview1);*/

if(t==0)
{
sprintf(text4,"le produit existe. veuillez continuer !!!");
output=lookup_widget(button,"label37jihen");
gtk_label_set_text(GTK_LABEL(output),text4);
chercher(ref);
treeview1=lookup_widget(button,"treeview1");
afficher_rech(treeview1);

}

else
{
sprintf(text4,"le produit n existe pas .veuillez verifier !!!");
output=lookup_widget(button,"label37jihen");
gtk_label_set_text(GTK_LABEL(output),text4);
}

}


void
on_modifier_jihen_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char texte3[20]="";
stock s;
GtkWidget* nom2;
GtkWidget* four2;
GtkWidget* quantite2;
GtkWidget* prix2;
GtkWidget* cat2;

GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget *treeview1;
GtkWidget* output;
gchar *ref;
char nom1[20];
//char ref1[20];
char cat1[20];
char rang1[20];
char quantite1[20];
char four1[20];
char prix1[20];

int jour,mois,annee;

treeview1=lookup_widget(button,"treeview1");
selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));
if(gtk_tree_selection_get_selected(selection,&model,&iter)&&(y2==1)) {
gtk_tree_model_get(model,&iter,1,&ref,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);

nom2=  lookup_widget(button, "njihen");
cat2= lookup_widget(button, "categoriejihen");
four2= lookup_widget(button, "fournisseurjihen");
quantite2= lookup_widget(button, "quantitejihen");
prix2= lookup_widget(button, "pjihen");



strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom2)));
strcpy(s.cat,gtk_entry_get_text(GTK_ENTRY(cat2)));
strcpy(s.four,gtk_entry_get_text(GTK_ENTRY(four2)));
strcpy(s.quantite,gtk_entry_get_text(GTK_ENTRY(quantite2)));
strcpy(s.prix,gtk_entry_get_text(GTK_ENTRY(prix2)));

modifier(ref,s);
sprintf(texte3,"modification faite");
output=lookup_widget(button, "label34jihen");
gtk_label_set_text(GTK_LABEL(output),texte3);}


else
{
sprintf(texte3,"erreur");
output=lookup_widget(button, "label34jihen");
gtk_label_set_text(GTK_LABEL(output),texte3);
}

}




void
on_supp_jihen_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
stock s;

char text[50]="";
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget* output;
GtkWidget *p=lookup_widget(button,"treeview1");
gchar *ref;


selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
if(gtk_tree_selection_get_selected(selection,&model,&iter))
{
gtk_tree_model_get(model,&iter,1,&ref,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
supprimer (ref);
sprintf(text,"suppression faite");
output=lookup_widget(button, "label35jihen");
gtk_label_set_text(GTK_LABEL(output),text);}

else
{
sprintf(text,"erreur");
output=lookup_widget(button, "label35jihen");
gtk_label_set_text(GTK_LABEL(output),text);
}


}




void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;





treeview1=lookup_widget(button,"treeview1");


afficher (treeview1);


}


void
on_actualiserjihen_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *stock;
GtkWidget *s;
GtkWidget *treeview1;

s=lookup_widget(button,"stock");
stock=create_stock();

gtk_widget_show(stock);

gtk_widget_hide(s);



treeview1=lookup_widget(button,"treeview1");
afficher (treeview1);
}







void
on_affichdashboard_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2;

FILE*g1;



treeview2=lookup_widget(button,"treeview2");

gestion(s);
dashboard(treeview2);

}


void
on_facebook_jihen_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
system ("firefox https://www.facebook.com/");
}


void
on_instagram_jihen_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
system ("firefox https://www.instagram.com/");
}

