#ifndef FINAL_H_INCLUDED
#define FINAL_H_INCLUDED

typedef struct dates
{   int j;
    int m;
    int a;
}date;
typedef struct stocks
{ char nom [20];
  char ref[20];
  char prix[20];
  char cat[20];
  char quantite [20];
  char four[20];
  char rang[20];
  char etat[20];
  date d;
}stock;
stock s;
int verif(char r[20]);
void ajouter (stock s);
void chercher (char ref[20]);

void supprimer (char ref[20] );
void afficher_stock();
void afficher(GtkWidget *liste );
void afficher_rech(GtkWidget *liste );
void actualiser(GtkWidget *liste );
void gestion (stock s);
void modifier(char ref[20],stock s1);
int controle(char ch[]);
void dashboard(GtkWidget *liste );



#endif // FINAL_H_INCLUDED
