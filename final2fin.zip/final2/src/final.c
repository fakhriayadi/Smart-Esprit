#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include<stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "final.h"

#include<support.h>
#include<string.h>
#include<stdlib.h>
enum {ENOM,
      EREF,
EPRIX,
ECAT,
EQUANTITE,
EFOUR,
ERANG,
EETAT,
EJOUR,
EMOIS,
EANNEE,
COLUMNS,
};
enum {ENOM1,
      EREF1,
EPRIX1,
ECAT1,
EQUANTITE1,
EFOUR1,
ERANG1,
EETAT1,
EJOUR1,
EMOIS1,
EANNEE1,
COLUMNS1,
};


void ajouter(stock s)
{FILE* f =NULL;
f=fopen("stock.txt","a+");
if (f!=NULL)
{
fprintf (f,"%s %s %s %s %s %s %s %s %d %d %d\n",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);
}
    else
    printf("impossible d'ouvrir le fichier");
fclose(f);
}




//////////////////////////////////
int verif(char r[20])
{int t=0;
stock s;
FILE *f;
f=fopen("stock.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a)!=EOF)
{
if (strcmp(s.ref,r)==0)
{
t=1;
}
}
}return t ;
}
////////////////////////////////////////////////
void afficher(GtkWidget *liste )
{	stock s;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f ;

	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ref",renderer,"text",EREF,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("cat",renderer,"text",ECAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("rang",renderer,"text",ERANG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("quantite",renderer,"text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("four",renderer,"text",EFOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("etat",renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		
	
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	

	f=fopen("stock.txt","r");
	if(f==NULL)
	
		printf("erreur ");
	
	else
	{
	f=fopen("stock.txt","a+");
	while((fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a))!=EOF)
	{
	
		
		gtk_list_store_append (store,&iter);
		gtk_list_store_set (store,&iter,ENOM,s.nom,EREF,s.ref,ECAT,s.cat,ERANG,s.rang,EQUANTITE,s.quantite,EFOUR,s.four,EPRIX,s.prix,EETAT,s.etat,EJOUR,s.d.j,EMOIS,s.d.m,EANNEE,s.d.a,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
}
//////////////////////////////////////////////////////////////////

void afficher_stock()
{
FILE *f;
stock s;
f=fopen("stock.txt","r");
if (f!=NULL)
{
while((fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a)!=EOF))
{
printf(" nom %s | reference %s | categorie %s | rangement %s | quantite %s | fournisseur %s | prix %s | etat %s | date dajout %d/%d/%d\n ",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);
}
}
fclose(f);
}
////////////////////////////////////
void supprimer (char ref[20])
{
stock s;
//stock s1;
FILE*f=NULL;
FILE*g=NULL;
f=fopen("stock.txt","r");
g=fopen("test.txt","a+");

while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a)!=EOF)
{ if(strcmp(ref,s.ref)!=0){
fprintf(g,"%s %s %s %s %s %s %s %s %d %d %d\n",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);}

}

fclose(f);
fclose(g);
remove("stock.txt");
rename("test.txt","stock.txt");
}

//////////////////////////////////
void modifier(char ref[20],stock s1)
{ stock s;
FILE*f=NULL;
FILE*g=NULL;
f=fopen("stock.txt","r");
g=fopen("test.txt","a+");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a)!= EOF)
{
if (strcmp(s.ref,ref)==0)
{
fprintf(g,"%s %s %s %s %s %s %s %s %d %d %d\n",s1.nom,s.ref,s1.cat,s.rang,s1.quantite,s1.four,s1.prix,s.etat,s.d.j,s.d.m,s.d.a) ;
}
else
{  
fprintf(g,"%s %s %s %s %s %s %s %s %d %d %d\n",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);
}
}
}
fclose(f);
fclose(g);
remove("stock.txt");
rename("test.txt","stock.txt");
}

////////////////////////////////////
void actualiser(GtkWidget *liste )
{
	stock s;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f ;

	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ref",renderer,"text",EREF,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("cat",renderer,"text",ECAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("rang",renderer,"text",ERANG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("quantite",renderer,"text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("four",renderer,"text",EFOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("etat",renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		
	}
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	
gtk_list_store_append (store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	//g_object_unref(store);
	



}

////////////////////////////////////
void chercher(char ref[20])
{stock s;
FILE*f=NULL;
FILE*g=NULL;

//f=remove("recherche.txt");
f=fopen("stock.txt","r");
g=fopen("recherche.txt","w"); 
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a )!=EOF){
if(strcmp(ref,s.ref)==0)
fprintf(g,"%s %s %s %s %s %s %s %s %d %d %d\n",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);
}
}
fclose(g);
fclose(f);
}
///////////////////////////////
/*void chercher(char ref[20],stock s)
{//stock s;
FILE*f=NULL;
FILE*g=NULL;
f=fopen("stock.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a )!=EOF)
{g=fopen("recherche.txt","w");
if (g!=NULL)
	   if(strcmp(s.ref,ref)==0)
	     fprintf(g,"%s %s %s %s %s %s %s %s %d %d %d",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a);}
             fclose(g);
             fclose(f);}

}
 */

///////////////////////////////////////////////////// affrech
void afficher_rech(GtkWidget *liste )
{	stock s;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *g ;

	FILE *f ;
	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ref",renderer,"text",EREF,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("cat",renderer,"text",ECAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("rang",renderer,"text",ERANG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("quantite",renderer,"text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("four",renderer,"text",EFOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("etat",renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		
	
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	

	g=fopen("recherche.txt","r");
	if(g==NULL)
	
		printf("erreur ");
	
	else
	{
	f=fopen("recherche.txt","a+");
	while((fscanf(g,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a))!=EOF)
	{
	
		
		gtk_list_store_append (store,&iter);
		gtk_list_store_set (store,&iter,ENOM,s.nom,EREF,s.ref,ECAT,s.cat,ERANG,s.rang,EQUANTITE,s.quantite,EFOUR,s.four,EPRIX,s.prix,EETAT,s.etat,EJOUR,s.d.j,EMOIS,s.d.m,EANNEE,s.d.a,-1);
	}
	fclose(g);
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
}
/////////////////////////////////
void gestion (stock s)

{   FILE* g1=NULL;
    FILE* f=NULL;
   // stock s;
 char etat [20]="en-repture-de-stock";
 char q[20]="0";
    f=fopen("stock.txt","r");
    g1=fopen("repture.txt","w");
    while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a)!=EOF)
    {  if ((strcmp(etat,s.etat)==0)&&(strcmp(q,s.quantite)==0))
               {fprintf(g1,"%s %s %s %s %s %s %s %s %d %d %d\n",s.nom,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,s.d.j,s.d.m,s.d.a); }
            
        }
        

fclose(f);
fclose(g1);
    }
/////////////////////////////
void dashboard(GtkWidget *liste )
{	stock s;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *g1 ;
	FILE *f ;

	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ref",renderer,"text",EREF,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("cat",renderer,"text",ECAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("rang",renderer,"text",ERANG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("quantite",renderer,"text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("four",renderer,"text",EFOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prix",renderer,"text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("etat",renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		
	
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	

	f=fopen("stock.txt","r");
	if(f==NULL)
	
		printf("erreur ");
	
	else
	{
	g1=fopen("repture.txt","a+");
	while((fscanf(g1,"%s %s %s %s %s %s %s %s %d %d %d",s.nom ,s.ref,s.cat,s.rang,s.quantite,s.four,s.prix,s.etat,&s.d.j,&s.d.m,&s.d.a))!=EOF)
	{
	
		
		gtk_list_store_append (store,&iter);
		gtk_list_store_set (store,&iter,ENOM,s.nom,EREF,s.ref,ECAT,s.cat,ERANG,s.rang,EQUANTITE,s.quantite,EFOUR,s.four,EPRIX,s.prix,EETAT,s.etat,EJOUR,s.d.j,EMOIS,s.d.m,EANNEE,s.d.a,-1);
	}
	fclose(f);

	fclose(g1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
}

/////////////////////////////////////

int controle(char ch[])

{
int len,i=0,x,test=0;
len = strlen(ch);

for(i=0;i<len;i++)
{
    if(isdigit(ch[i])==0)
    {
        test=1;
    }

}
return test;

}




