#include <gtk/gtk.h>


void
on_radiobuttonGhazela_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCharguia_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonAjouterEV_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewEV_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonSupprEV_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonRechercherEV_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonModifEV_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonAfficherEV_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonActualiserEV_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1cnf_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_butttonPETAGE_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);
