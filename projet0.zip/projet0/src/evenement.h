#ifndef EVENEMENT_H_INCLUDED
#define EVENEMENT_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>

typedef struct {

char id [30] ;
char nom [30];
char lieu[30];
char type [30];
int jour;
int mois;
int annee;
int nbre_participant ;
}evenement;

typedef struct capteur_debit
{
    int heure;
    int jour;
    int etage;
    float val;
}capteur_debit;



void afficher (GtkWidget *liste);
int ajouter(evenement E);
void rechercher(GtkWidget *liste,char ID[30]);
int supprimer(char ID [20]);
int modifier(evenement E);
int verif(char *id);
void etage_debit(GtkWidget *liste);

#endif // EVENEMENT_H_INCLUDED




