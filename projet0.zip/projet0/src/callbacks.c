#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "evenement.h"
int lieu=1;

void
on_radiobuttonGhazela_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	lieu=1;
}


void
on_radiobuttonCharguia_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
	lieu=2;
}

////////////////////////////////////////////////////////////////////////
void
on_buttonAjouterEV_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
evenement E;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8;
GtkWidget *Espace_evenement, *outputMsg;
int ajout,test;
char text[30];

Espace_evenement=lookup_widget(objet,"Espace_evenement");

input1=lookup_widget(objet,"entrynomEV");
input2=lookup_widget(objet,"entryidEV");
input3=lookup_widget(objet,"spinbuttonJourEV");
input4=lookup_widget(objet,"spinbuttonMoisEV");
input5=lookup_widget(objet,"spinbuttonAnneeEV");
input6=lookup_widget(objet,"comboboxTypeEV");
input7=lookup_widget(objet,"spinbuttonNBR");


strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(E.id,gtk_entry_get_text(GTK_ENTRY(input2)));
E.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
E.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
E.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
E.nbre_participant = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));;

if(lieu==1)
strcpy(E.lieu,"Esprit_Ghazela");
else 
if
(lieu==2)
strcpy(E.lieu,"Esprit_Charguia");


//ajouter(E);

test=verif(E.id);

switch(test)
    
{
    case 0:  
    { ajout=ajouter(E); 
     strcpy (text,"Ajout Réussi");
     outputMsg=lookup_widget(objet,("msgresult"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;
    case 1:
    { strcpy (text,"Identifiant déja existe");
    outputMsg=lookup_widget(objet,("msgresult"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
}
}
////////////////////////////////////////////////////

void
on_treeviewEV_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

int conf=0;

void
on_buttonSupprEV_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

        GtkWidget *input1;
     	GtkWidget *Espace_evenement;
     	GtkWidget *outputMsg;
	
evenement E;
	
     int test,supp;
     char text[200];
   char ID [20];
     




Espace_evenement=lookup_widget(objet,"Espace_evenement");
input1=lookup_widget(objet,"entryRefEVmod");   
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(input1)));

if (conf)
{
test=verif(ID);


switch(test)
    
{
    case 0:
   
     
    { strcpy (text,"Ref Evenement n'existe pas");
    outputMsg=lookup_widget(objet,("labelMsG"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
  
    break;
    case 1:
     
     {
     supp=supprimer(ID);
     strcpy (text,"Suppression Réussi");
     outputMsg=lookup_widget(objet,("labelMsG"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;

}
}
else 
{strcpy (text,"La confirmation est obligatoire!");
    outputMsg=lookup_widget(objet,("labelMsG"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
}

void
on_buttonRechercherEV_clicked                    ( GtkWidget *objet, gpointer   user_data)
{
 	GtkWidget *Espace_evenement;
   	GtkWidget *idRech;
   	GtkWidget *treeview2;
      	GtkWidget *outputMsg;
   	int test;
    	char text[200];
   	char ID[20];
   
Espace_evenement=lookup_widget(objet,"Espace_evenement");
treeview2=lookup_widget(Espace_evenement,"treeviewEV");

idRech=lookup_widget(objet,"entryRef_recherchEV");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(idRech)));

test=verif(ID);

switch(test)
    
{
    case 0:  
    { strcpy (text,"Evenement n'existe pas");
    outputMsg=lookup_widget(objet,("labelMsG"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;
    case 1:
   
    {  rechercher(treeview2, ID);
       strcpy (text,"Evenement trouvé");
       outputMsg=lookup_widget(objet,("labelMsG"));
       gtk_label_set_text(GTK_LABEL(outputMsg),text);
      }
    break; 
    break;
} 

}


void
on_buttonModifEV_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
evenement E;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *input7, *input8,*modifID;
GtkWidget *Espace_evenement, *outputMsg;
int modif,test;
char text[30];

Espace_evenement=lookup_widget(objet,"Espace_evenement");

input1=lookup_widget(objet,"entrynomEV");
input2=lookup_widget(objet,"entryidEV");
input3=lookup_widget(objet,"spinbuttonJourEV");
input4=lookup_widget(objet,"spinbuttonMoisEV");
input5=lookup_widget(objet,"spinbuttonAnneeEV");
input6=lookup_widget(objet,"comboboxTypeEV");
input7=lookup_widget(objet,"spinbuttonNBR");



strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(E.id,gtk_entry_get_text(GTK_ENTRY(input2)));
E.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
E.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
E.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
E.nbre_participant = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));;

if(lieu==1)
strcpy(E.lieu,"Esprit_Ghazela");
else 
if
(lieu==2)
strcpy(E.lieu,"Esprit_Charguia");


test=verif(E.id);

switch(test)
    
{
    case 0:
    { strcpy(text,"Evenement n'existe pas");
    outputMsg=lookup_widget(objet,("msgresult"));
    gtk_label_set_text(GTK_LABEL(outputMsg),text);
    }
    break;

    case 1:
     
     {modif=modifier(E);
     strcpy (text,"Modification Réussi");
     outputMsg=lookup_widget(objet,("msgresult"));
     gtk_label_set_text(GTK_LABEL(outputMsg),text);
     }
    break;

}
}


void
on_buttonAfficherEV_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_evenement;
GtkWidget *treeview1;

Espace_evenement=lookup_widget(objet,"Espace_evenement");
treeview1=lookup_widget(Espace_evenement,"treeviewEV");

afficher(treeview1);



}


void
on_buttonActualiserEV_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_evenement;
GtkWidget *treeview1;

Espace_evenement=lookup_widget(objet,"Espace_evenement");
treeview1=lookup_widget(Espace_evenement,"treeviewEV");


vider(treeview1);
afficher(treeview1);



}


void
on_checkbutton1cnf_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
conf=1;
else
conf=0;
}


void
on_butttonPETAGE_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_evenement;
GtkWidget *treeviewETAG;

Espace_evenement=lookup_widget(objet,"Espace_evenement");
treeviewETAG=lookup_widget(Espace_evenement,"treeview2PETAGE");

etage_debit (treeviewETAG);
}

