#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "evenement.h"
#include <gtk/gtk.h>



int ajouter(evenement E)
{
    FILE* f;
    f=fopen("evenement.txt","a");

    if (f!=NULL)
        {
        fprintf(f,"%s %s %s %s %d  %d %d %d\n",E.nom,E.id,E.type,E.lieu,E.nbre_participant,E.jour,E.mois,E.annee);
        fclose(f);
	return 1;
        }
	else
	return 0;
        }
//////////////////////////////////////////////
enum 
{	
	Enom,
	Eid,
        Etype,
        Elieu,
        Enbre_participant, 
        Ejour,
	Emois,
	Eannee,
	COLUMNS 
};




void afficher(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char nom [30];
	char id [30] ;
	char type[30] ;
	char lieu [30];
	int nbre_participant ;
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom", renderer, "text",Enom, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id", renderer, "text",Eid, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("type", renderer, "text",Etype, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("lieu", renderer, "text",Elieu, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nbre_participant", renderer, "text",Enbre_participant, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",Ejour, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",Emois, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",Eannee, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
f=fopen("evenement.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("evenement.txt","a+");
	while(fscanf(f,"%s %s %s %s %d %d %d %d",nom,id,type,lieu, &nbre_participant, &jour, &mois, &annee)!=EOF)
	{
         
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, Enom, nom, Eid, id, Etype, type, Elieu, lieu, Enbre_participant, nbre_participant, Ejour, jour, Emois, mois, Eannee, annee,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
/////////////////////////////////////////////////////////////////////////////////
void rechercher(GtkWidget *liste, char ID[20])

{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char nom [30];
	char id [30] ;
	char type[30] ;
	char lieu [30];
	int nbre_participant ;
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom", renderer, "text",Enom, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id", renderer, "text",Eid, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("type", renderer, "text",Etype, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("lieu", renderer, "text",Elieu, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nbre_participant", renderer, "text",Enbre_participant, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",Ejour, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",Emois, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",Eannee, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
}
	
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
f=fopen("evenement.txt","r");
if(f==NULL)
{
return;
}
	else
		{
 f = fopen("evenement.txt","a+");
	while(fscanf(f,"%s %s %s %s %d %d %d %d",nom,id,type,lieu, &nbre_participant, &jour, &mois, &annee)!=EOF)
	{
		 if(strcmp(id,ID)==0)                						  
		{
		gtk_list_store_append(store, &iter);						  			 	
		gtk_list_store_set (store, &iter, Enom, nom, Eid, id, Etype, type, Elieu, lieu, Enbre_participant, nbre_participant, Ejour, jour, Emois, mois, Eannee, annee,-1);		
	}
		}
		fclose(f);
        	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
}



//////////////////////////////////////////////////////////////////////////////////
void vider(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;


	char nom [30];
	char id [30] ;
	char type[30] ;
	char lieu [30];
	int nbre_participant ;
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer, "text", Enom, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id",renderer, "text", Eid, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("type", renderer, "text", Etype, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("lieu", renderer, "text", Elieu, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nbre_participant", renderer, "text", Enbre_participant, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",Ejour, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",Emois, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",Eannee, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


}
	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT); 
	gtk_list_store_append(store,&iter);						  			 
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
}


/////////////////////////////////
/******supprimer******/
int supprimer(char ID[20])
{
evenement E;

	
FILE *f = NULL;
FILE *f1 = NULL;

f=fopen("evenement.txt","r");
f1=fopen("tmp.txt","w");
if (f!=NULL){

while(fscanf(f,"%s %s %s %s %d %d %d %d",E.nom,E.id,E.type,E.lieu,&E.nbre_participant,&E.jour,&E.mois,&E.annee)!=EOF)
    {

if (strcmp(E.id, ID)!=0){
fprintf(f1,"%s %s %s %s %d  %d  %d  %d\n",E.nom,E.id,E.type,E.lieu,E.nbre_participant,E.jour,E.mois,E.annee);
   }
   }
   }
fclose(f);
fclose(f1);
remove("evenement.txt");
rename("tmp.txt" , "evenement.txt");
return 1 ;

}   

/*

void supprimer(evenement E){

FILE *f;
FILE *f1;

evenement e;
f=fopen("evenement.txt","r");
f1=fopen("temp.txt","w");


    if (f==NULL || f1==NULL )
    {
	return;
    }
    else{
    	while(fscanf(f,"%s %s %s %s %d %d %d %d",e.nom,e.id,e.type,e.lieu,&e.nbre_participant,&e.jour,&e.mois,&e.annee)!=EOF)
    {
	if(strcmp(e.id,E.id)!=0 )
        fprintf(f1,"%s %s %s %s %d  %d  %d  %d\n",e.nom,e.id,e.type,e.lieu,e.nbre_participant,e.jour,e.mois,e.annee);
else
fprintf(f1,"%s %s %s %s %d  %d  %d  %d\n",E.nom,E.id,E.type,E.lieu,E.nbre_participant,E.jour,E.mois,E.annee);
}
}
fclose(f);
fclose(f1);
remove("evenement.txt");
rename("temp.txt","evenement.txt");

}


*/


//////////////////////////////////////////

int verif(char *id)
{
evenement E;
FILE *f;
f=fopen("evenement.txt","r");
if (f!=NULL){

while(fscanf(f,"%s %s %s %s %d %d %d %d",E.nom,E.id,E.type,E.lieu,&E.nbre_participant,&E.jour,&E.mois,&E.annee)!=EOF)
{
if (strcmp(E.id,id)==0)
return 1;
}
fclose(f);
return 0;
}
}

///////////////////////////////////////////////////////////////////
int modifier(evenement E)
{
evenement e;	
FILE*f;
FILE*f1;
f=fopen("evenement.txt","r");
f1=fopen("tmp.txt","w");

if ((f!=NULL) && (f1!=NULL))
    {
while(fscanf(f,"%s %s %s %s %d %d %d %d ",e.nom,e.id,e.type,e.lieu,&e.nbre_participant,&e.jour,&e.mois,&e.annee)!=EOF)
    {
if(strcmp(E.id,e.id)!=0)
    {
fprintf(f1,"%s %s %s %s %d  %d  %d  %d\n",e.nom,e.id,e.type,e.lieu,e.nbre_participant,e.jour,e.mois,e.annee);
    }
else
    {

fprintf(f1,"%s %s %s %s %d  %d  %d  %d\n",E.nom,E.id,E.type,E.lieu,E.nbre_participant,E.jour,E.mois,E.annee);
    }
    }
fclose(f);
fclose(f1);

remove("evenement.txt");
rename("tmp.txt","evenement.txt");
return 1;
}
}

//////////////////////////////////////////////////////////////////////
/*
 void etage_debit(char debit[]){
FILE* f=NULL;
capteur_debit c;
f=fopen("debit.txt","r");
while(fscanf(f,"%d %d %d %f\n",&c.jour,&c.heure,&c.id,&c.val)!=EOF)
{
if(c.val>30)
{
printf("le capteur def est dans etage %d,jour %d,heure %d avec la valeur %.2f\n",c.id,c.jour,c.heure,c.val);
}
}
fclose(f);
}
*/
//////////////////////////////////
	
enum
{	
	ETAGE,
	JOUR,
        HEURE,
        VAL,
	COLUMNS1 
};



void etage_debit(GtkWidget *liste)

{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	int etage;
	int jour;
	int heure;
    	float val;
	store=NULL;

FILE *f4;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Etage", renderer, "text",ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Jour", renderer, "text",JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Heure", renderer, "text",HEURE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" valeur Debit", renderer, "text",VAL, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);

}
	
store=gtk_list_store_new(COLUMNS1, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT , G_TYPE_FLOAT);
f4 = fopen("debit.txt","r");
if(f4 == NULL)
{
return;
}
	else
		{
 	f4 = fopen("debit.txt","a+");

	while(fscanf(f4,"%d %d %d %f\n",&jour,&heure,&etage,&val)!=EOF)
	{
		 if (val>30)                						  
		{
		gtk_list_store_append(store, &iter);						  			 	
		gtk_list_store_set (store, &iter, ETAGE, etage, JOUR, jour, HEURE, heure, VAL, val,-1);		
	}
		}
		fclose(f4);
        	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
}


